from django.apps import AppConfig


class DjangoSwitchboardOperatorConfig(AppConfig):
    name = 'django_switchboard_operator'
